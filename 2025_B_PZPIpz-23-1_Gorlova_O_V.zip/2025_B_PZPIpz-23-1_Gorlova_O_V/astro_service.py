import swisseph as swe
import datetime
import pytz
import os
from flask_babel import gettext as _ # Для перекладів

# --- Налаштування Swiss Ephemeris ---
EPHE_PATH = './ephe' # Вказуємо відносний шлях до папки 'ephe'

try:
    swe.set_ephe_path(EPHE_PATH)
    print(f"Swiss Ephemeris data path set to: {EPHE_PATH}")
except Exception as e:
    print(f"ERROR: Failed to set Swiss Ephemeris data path. Check if '{EPHE_PATH}' exists and contains ephemeris files. Error: {e}")
    raise

# --- Константи для біодинаміки ---

# Maria Thun's specific mapping from Constellation Name to Element
CONSTELLATION_ELEMENTS_MT = {
    'Aries': 'Fire',
    'Taurus': 'Earth',
    'Gemini': 'Air',
    'Cancer': 'Water',
    'Leo': 'Fire',
    'Virgo': 'Earth',
    'Libra': 'Air',
    'Scorpio': 'Water',
    'Ophiuchus': 'Water', # Змієносець, часто асоціюється з водою в біодинаміці
    'Sagittarius': 'Fire',
    'Capricornus': 'Earth',
    'Aquarius': 'Air',
    'Pisces': 'Water'
}

# Словник для перекладу місяців
MONTH_NAMES = {
    1: _('January'), 2: _('February'), 3: _('March'), 4: _('April'), 5: _('May'), 6: _('June'),
    7: _('July'), 8: _('August'), 9: _('September'), 10: _('October'), 11: _('November'), 12: _('December')
}

# Словник для перекладу днів тижня
WEEKDAY_NAMES = {
    0: _('Monday'), 1: _('Tuesday'), 2: _('Wednesday'), 3: _('Thursday'),
    4: _('Friday'), 5: _('Saturday'), 6: _('Sunday')
}

# Стихії з перекладами
ELEMENTS_TRANSLATION = {
    'Fire': _('Fire'),
    'Earth': _('Earth'), 
    'Air': _('Air'),
    'Water': _('Water')
}

# Типи днів з перекладами
DAY_TYPES = {
    'Fire': _('Fruit'),
    'Earth': _('Root'),
    'Air': _('Flower'),
    'Water': _('Leaf')
}

# Сузір'я з перекладами
CONSTELLATION_TRANSLATIONS = {
    'Aries': _('Aries'),
    'Taurus': _('Taurus'),
    'Gemini': _('Gemini'),
    'Cancer': _('Cancer'),
    'Leo': _('Leo'),
    'Virgo': _('Virgo'),
    'Libra': _('Libra'),
    'Scorpio': _('Scorpio'),
    'Ophiuchus': _('Ophiuchus'),
    'Sagittarius': _('Sagittarius'),
    'Capricornus': _('Capricornus'),
    'Aquarius': _('Aquarius'),
    'Pisces': _('Pisces')
}

# --- Допоміжні функції для астрономічних розрахунків ---

def get_julian_day_ut(year, month, day, hour=0, minute=0, second=0):
    """Повертає Юліанську дату (Universal Time) для вказаного часу."""
    return swe.julday(year, month, day, hour + minute / 60.0 + second / 3600.0)

def get_moon_position_ut(jd_ut):
    """Повертає тропічну екліптичну довготу та широту Місяця."""
    xx, _dummy = swe.calc_ut(jd_ut, swe.MOON, 2 | 4)
    return xx[0], xx[1] # довгота, широта

def get_moon_constellation(jd_ut):
    """
    Визначає астрономічне сузір'я, в якому знаходиться Місяць,
    на основі її екліптичної довготи та попередньо визначених меж.
    """
    moon_long, _dummy = get_moon_position_ut(jd_ut)
    
    # Нормалізуємо довготу до діапазону [0, 360)
    moon_long = moon_long % 360
    if moon_long < 0:
        moon_long += 360

    # Приблизні межі сузір'їв IAU
    CONSTELLATION_DEGREES = [
        (337.0, "Pisces"),
        (33.0, "Aries"),
        (54.0, "Taurus"),
        (86.0, "Gemini"),
        (116.0, "Cancer"),
        (139.0, "Leo"),
        (174.0, "Virgo"),
        (218.0, "Libra"),
        (240.0, "Scorpio"),
        (260.0, "Ophiuchus"), # Змієносець
        (270.0, "Sagittarius"),
        (300.0, "Capricornus"),
        (319.0, "Aquarius"),
    ]

    # Шукаємо сузір'я, в якому знаходиться Місяць
    if (moon_long >= CONSTELLATION_DEGREES[0][0] and moon_long <= 360) or \
       (moon_long >= 0 and moon_long < CONSTELLATION_DEGREES[1][0]):
        return "Pisces"
    
    for i in range(len(CONSTELLATION_DEGREES) - 1, 0, -1):
        start_degree, constellation_name = CONSTELLATION_DEGREES[i]
        if moon_long >= start_degree:
            return constellation_name
    return "Aries"

def get_planet_longitude_ut(jd_ut, planet_id):
    """Повертає тропічну екліптичну довготу планети в градусах."""
    xx, _dummy = swe.calc_ut(jd_ut, planet_id, 2 | 4)
    return xx[0]

def get_moon_constellation_change_time(dt_dt, tz_obj):
    """
    Перевіряє, чи змінює Місяць сузір'я протягом доби, і повертає його назву
    та час переходу в місцевому часі.
    """
    dt_local_start_of_day_utc = tz_obj.localize(datetime.datetime(dt_dt.year, dt_dt.month, dt_dt.day, 0, 0, 0)).astimezone(pytz.utc)
    jd_ut_start = swe.utc_to_jd(dt_local_start_of_day_utc.year, dt_local_start_of_day_utc.month, dt_local_start_of_day_utc.day,
                                dt_local_start_of_day_utc.hour, dt_local_start_of_day_utc.minute, dt_local_start_of_day_utc.second)[0]

    constellation_start = get_moon_constellation(jd_ut_start)
    
    for hour in range(24):
        for minute in range(0, 60, 10):
            check_dt_local = tz_obj.localize(datetime.datetime(dt_dt.year, dt_dt.month, dt_dt.day, hour, minute, 0))
            check_jd_ut = swe.utc_to_jd(check_dt_local.astimezone(pytz.utc).year, check_dt_local.astimezone(pytz.utc).month,
                                        check_dt_local.astimezone(pytz.utc).day,
                                        check_dt_local.astimezone(pytz.utc).hour, check_dt_local.astimezone(pytz.utc).minute,
                                        check_dt_local.astimezone(pytz.utc).second)[0]
            
            constellation_at_minute = get_moon_constellation(check_jd_ut)
            if constellation_at_minute != constellation_start:
                # Повертаємо перекладену назву сузір'я
                return f"{CONSTELLATION_TRANSLATIONS.get(constellation_at_minute, constellation_at_minute)} {check_dt_local.strftime('%H:%M')}"
    return None

def get_moon_phase(jd_ut):
    """Визначає фазу Місяця за Юліанською датою UT."""
    moon_long, _dummy = get_moon_position_ut(jd_ut)
    xx_sun, _dummy = swe.calc_ut(jd_ut, swe.SUN, 2 | 4)
    sun_long = xx_sun[0]
    phase_angle = (moon_long - sun_long + 360) % 360

    if 337.5 <= phase_angle or phase_angle < 22.5: return _('New Moon')
    elif 22.5 <= phase_angle < 67.5: return _('Waxing Crescent')
    elif 67.5 <= phase_angle < 112.5: return _('First Quarter')
    elif 112.5 <= phase_angle < 157.5: return _('Waxing Gibbous')
    elif 157.5 <= phase_angle < 202.5: return _('Full Moon')
    elif 202.5 <= phase_angle < 247.5: return _('Waning Gibbous')
    elif 247.5 <= phase_angle < 292.5: return _('Last Quarter')
    else: return _('Waning Crescent')

def get_aspects(jd_ut):
    """Перевірка аспектів Місяця з великими планетами."""
    moon_long, _dummy = get_moon_position_ut(jd_ut)
    aspects = []
    
    PLANETS_FOR_ASPECTS = [
        (swe.SUN, _('Sun')), (swe.MERCURY, _('Mercury')), (swe.VENUS, _('Venus')),
        (swe.MARS, _('Mars')), (swe.JUPITER, _('Jupiter')), (swe.SATURN, _('Saturn')),
        (swe.URANUS, _('Uranus')), (swe.NEPTUNE, _('Neptune')), (swe.PLUTO, _('Pluto'))
    ]

    ASPECTS_DEFINITIONS = {
        0: {'symbol': '☌', 'name': _('Conjunction'), 'orb': 3}, 
        60: {'symbol': '⚹', 'name': _('Sextile'), 'orb': 2},
        90: {'symbol': '□', 'name': _('Square'), 'orb': 3}, 
        120: {'symbol': '△', 'name': _('Trine'), 'orb': 2},
        180: {'symbol': '☍', 'name': _('Opposition'), 'orb': 3}
    }

    for planet_id, planet_name in PLANETS_FOR_ASPECTS:
        planet_long = get_planet_longitude_ut(jd_ut, planet_id)
        diff_raw = abs(moon_long - planet_long) % 360
        diff = min(diff_raw, 360 - diff_raw)
        for aspect_angle, aspect_info in ASPECTS_DEFINITIONS.items():
            if abs(diff - aspect_angle) <= aspect_info['orb']:
                aspects.append(f"{_('Moon')} {aspect_info['symbol']} {planet_name}")
    
    return ', '.join(aspects) if aspects else None

def get_apogee_perigee(jd_ut):
    """Перевіряє відстань Місяця до Землі та визначає апогей/перигей."""
    moon_pos, _dummy = swe.calc_ut(jd_ut, swe.MOON, 2 | 2048)
    distance_km = moon_pos[2] * 149597870.7
    if distance_km < 363300: return _('Perigee')
    elif distance_km > 405500: return _('Apogee')
    return None

def get_eclipse(jd_ut, lat, lon):
    """
    Перевіряє наявність затемнень з умовною перевіркою доступності функцій.
    """
    # Перевіряємо, чи доступні функції затемнень
    if not hasattr(swe, 'sol_eclipse_when_loc') or not hasattr(swe, 'lun_eclipse_when_loc'):
        print("Функции затмений недоступны в текущей версии Swiss Ephemeris")
        return None
    
    try:
        geopos_tuple = (lon, lat, 0)
        flags = swe.FLG_SWIEPH
        SEARCH_INTERVAL = 0.6
        
        # Перевірка сонячного затемнення
        try:
            ret_sol_info = swe.sol_eclipse_when_loc(jd_ut - SEARCH_INTERVAL, flags, geopos_tuple)
            if ret_sol_info and ret_sol_info[0] != 0:
                found_eclipse_time_jd = ret_sol_info[1][0]
                eclipse_type_flags = ret_sol_info[0]
                
                if (abs(found_eclipse_time_jd - jd_ut) < SEARCH_INTERVAL and 
                    eclipse_type_flags & (swe.ECL_TOTAL | swe.ECL_PARTIAL | swe.ECL_ANNULAR)):
                    return _('Solar Eclipse')
        except Exception as e:
            print(f"Ошибка солнечного затмения: {e}")
        
        # Перевірка місячного затемнення
        try:
            ret_lun_info = swe.lun_eclipse_when_loc(jd_ut - SEARCH_INTERVAL, flags, geopos_tuple)
            if ret_lun_info and ret_lun_info[0] != 0:
                found_eclipse_time_jd = ret_lun_info[1][0]
                eclipse_type_flags = ret_lun_info[0]
                
                if (abs(found_eclipse_time_jd - jd_ut) < SEARCH_INTERVAL and 
                    eclipse_type_flags & (swe.ECL_TOTAL | swe.ECL_PARTIAL | swe.ECL_PENUMBRAL)):
                    return _('Lunar Eclipse')
        except Exception as e:
            print(f"Ошибка лунного затмения: {e}")
            
    except Exception as e:
        print(f"Общая ошибка в get_eclipse: {e}")
    
    return None

def get_day_recommendations(constellation_name, element_type, day_type):
    """Генерація рекомендацій на день."""
    if constellation_name in ['Ophiuchus', 'Serpentarius']:
        return _('Unproductive period. Avoid planting.')
    if day_type == 'Fruit': return _('Good for sowing fruiting plants.')
    elif day_type == 'Root': return _('Good for sowing root vegetables.')
    elif day_type == 'Flower': return _('Ideal for flowering plants care.')
    elif day_type == 'Leaf': return _('Suitable for leafy crops care.')
    else: return _('Normal day.')

def get_month_calendar(year, month, lat, lon, timezone_str, today_local):
    """
    Основна функція: будує календар на місяць з біодинамічними даними.
    """
    calendar_data = []
    tz_obj = pytz.timezone(timezone_str)
    
    if month == 12:
        num_days = 31
    else:
        num_days = (datetime.date(year, month + 1, 1) - datetime.timedelta(days=1)).day

    for day in range(1, num_days + 1):
        local_dt_noon = tz_obj.localize(datetime.datetime(year, month, day, 12, 0, 0))
        jd_ut_noon = swe.utc_to_jd(local_dt_noon.astimezone(pytz.utc).year, 
                                   local_dt_noon.astimezone(pytz.utc).month,
                                   local_dt_noon.astimezone(pytz.utc).day,
                                   local_dt_noon.astimezone(pytz.utc).hour, 
                                   local_dt_noon.astimezone(pytz.utc).minute,
                                   local_dt_noon.astimezone(pytz.utc).second)[0]

        moon_constellation_raw = get_moon_constellation(jd_ut_noon)
        moon_constellation = CONSTELLATION_TRANSLATIONS.get(moon_constellation_raw, moon_constellation_raw)
        
        element_raw = CONSTELLATION_ELEMENTS_MT.get(moon_constellation_raw)
        element = ELEMENTS_TRANSLATION.get(element_raw, element_raw) if element_raw else None
        
        day_type_raw = DAY_TYPES.get(element_raw) if element_raw else None
        day_type = day_type_raw  # DAY_TYPES вже містить переклади
        
        dt_for_change_check = datetime.datetime(year, month, day)
        moon_constellation_change = get_moon_constellation_change_time(dt_for_change_check, tz_obj)
        
        recommendations = get_day_recommendations(moon_constellation_raw, element_raw, day_type_raw)
        
        # Форматування дати з перекладом
        formatted_date = f"{local_dt_noon.strftime('%d')} {MONTH_NAMES[month]}"
        weekday_name = WEEKDAY_NAMES[local_dt_noon.weekday()]

        calendar_data.append({
            'formatted_date': formatted_date,
            'weekday': weekday_name,
            'moon_constellation': moon_constellation,
            'moon_constellation_change': moon_constellation_change,
            'moon_phase': get_moon_phase(jd_ut_noon),
            'element': element,
            'day_type': day_type,
            'aspects': get_aspects(jd_ut_noon),
            'apogee_perigee': get_apogee_perigee(jd_ut_noon),
            'eclipse': get_eclipse(jd_ut_noon, lat, lon),
            'recommendations': recommendations,
            'is_today': local_dt_noon.date() == today_local
        })
    return calendar_data