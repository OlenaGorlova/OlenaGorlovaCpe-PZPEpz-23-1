import json
from collections import defaultdict

ALL_COUNTRIES_FILE = 'allCountries.txt'
ALTERNATE_NAMES_FILE = 'alternateNames.txt'
OUTPUT_FILE = 'cities_multi_lang_filtered.json'

print("Чтение переводов...")
translations = defaultdict(dict)

with open(ALTERNATE_NAMES_FILE, encoding='utf-8', errors='ignore') as f:
    for line in f:
        parts = line.strip().split('\t')
        if len(parts) < 4:
            continue
        _, geonameid, lang, name = parts[:4]
        if lang in ('ru', 'uk', 'en'):
            translations[int(geonameid)][lang] = name

# Списки стран
europe_countries = {
    'AL', 'AD', 'AM', 'AT', 'AZ', 'BY', 'BE', 'BA', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR',
    'GE', 'DE', 'GR', 'HU', 'IS', 'IE', 'IT', 'KZ', 'XK', 'LV', 'LI', 'LT', 'LU', 'MT', 'MD', 'MC',
    'ME', 'NL', 'MK', 'NO', 'PL', 'PT', 'RO', 'RU', 'RS', 'SK', 'SI', 'ES', 'SE', 'CH', 'TR', 'UA', 'GB'
}
north_america_countries = {'US', 'CA'}

print("Формирование и запись города...")
with open(ALL_COUNTRIES_FILE, 'r', encoding='utf-8', errors='ignore') as f_in, \
     open(OUTPUT_FILE, 'w', encoding='utf-8') as f_out:

    f_out.write('[\n')  # начало массива
    first = True

    for line in f_in:
        parts = line.strip().split('\t')
        if len(parts) < 19:
            continue

        geonameid = int(parts[0])
        name = parts[1]
        lat = float(parts[4])
        lon = float(parts[5])
        feature_class = parts[6]
        country = parts[8]
        population = int(parts[14]) if parts[14].isdigit() else 0
        timezone = parts[17]

        if feature_class != 'P':
            continue

        # Фильтрация:
        if country == 'UA':
            pass  # все населённые пункты Украины
        elif country in europe_countries:
            if population < 50000:
                continue
        elif country in north_america_countries:
            if population < 100000:
                continue
        else:
            if population < 500000:
                continue

        names = {
            'en': translations[geonameid].get('en', name),
            'ru': translations[geonameid].get('ru', ''),
            'uk': translations[geonameid].get('uk', '')
        }

        city = {
            'id': geonameid,
            'name': names,
            'lat': lat,
            'lon': lon,
            'tz': timezone,
            'country': country
        }

        # Пишем в файл по одному объекту
        if not first:
            f_out.write(',\n')
        f_out.write(json.dumps(city, ensure_ascii=False))
        first = False

    f_out.write('\n]\n')  # конец массива

print(f"Готово! Файл: {OUTPUT_FILE}")
