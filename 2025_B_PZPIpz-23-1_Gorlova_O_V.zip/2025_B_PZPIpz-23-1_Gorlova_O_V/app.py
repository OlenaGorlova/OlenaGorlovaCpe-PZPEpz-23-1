from flask import Flask, request, render_template, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime, timedelta
import datetime as dt
import os
from functools import wraps
import json
import requests
import random
import secrets
import string

# --- Імпорти для календаря ---
from flask_babel import Babel, _, format_date
import pytz
try:
    from geoip2.database import Reader
except ImportError:
    print("Warning: geoip2 not installed. Location detection will be limited.")
    Reader = None

try:
    from astro_service import get_month_calendar
except ImportError:
    print("Warning: astro_service not found. Calendar generation will not work.")
    get_month_calendar = None

# --- Ініціалізація додатку та розширень ---
app = Flask(__name__)

# --- Конфігурація ---
app.config['SECRET_KEY'] = 'hfsjkdfuuw7284899hfni9aj920'  # СЕКРЕТНИЙ КЛЮЧ
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///biodyne_admin.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['BABEL_DEFAULT_LOCALE'] = 'en'
app.config['BABEL_TRANSLATION_DIRECTORIES'] = './translations'  # Шлях до папки translations

# --- Ініціалізація розширень ---
db = SQLAlchemy(app)
migrate = Migrate(app, db)
babel = Babel(app)

# --- API-ключі та налаштування ---
# API-ключ OpenWeatherMap
WEATHER_API_KEY = 'b4b0904e2d33efb90b4844388f71b95c'  # КЛЮЧ OpenWeatherMap

# Шлях до бази даних GeoLite2-Country.mmdb
GEOIP_DATABASE_PATH = os.path.join(app.root_path, 'static', 'IP', 'GeoLite2-Country.mmdb')
geoip_reader = None
if Reader and os.path.exists(GEOIP_DATABASE_PATH):
    try:
        geoip_reader = Reader(GEOIP_DATABASE_PATH)
    except Exception as e:
        print(f"Error loading the GeoLite2 database: {e}. Localization by IP will be limited..")
else:
    print("GeoLite2 database was not found. Localization by IP will be limited.")

# --- Моделі бази даних ---
class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=True)  # Пароль для користувачів
    city = db.Column(db.String(100))
    
    # ПОЛЯ для координат та часового поясу
    city_latitude = db.Column(db.Float, nullable=True)
    city_longitude = db.Column(db.Float, nullable=True)
    city_timezone = db.Column(db.String(50), nullable=True)
    
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_subscribed = db.Column(db.Boolean, default=False)
    subscription_date = db.Column(db.DateTime)
    notification_method = db.Column(db.String(50))  # email, mobile, both
    theme_preference = db.Column(db.String(20))  # light, dark, auto
    interested_crops = db.Column(db.Text)  # JSON string
    phone = db.Column(db.String(20))
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    profile_completed = db.Column(db.Boolean, default=False)

class PageView(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    page_name = db.Column(db.String(100), nullable=False)
    user_ip = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    session_id = db.Column(db.String(100))

class CalendarGeneration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    city = db.Column(db.String(100))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    month = db.Column(db.Integer)
    year = db.Column(db.Integer)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_ip = db.Column(db.String(45))

class Subscription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    plan_type = db.Column(db.String(50))  # basic, premium, professional
    status = db.Column(db.String(20))  # active, expired, cancelled
    start_date = db.Column(db.DateTime, default=datetime.utcnow)
    end_date = db.Column(db.DateTime)
    payment_amount = db.Column(db.Float)
    payment_method = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Модель для платіжних методів    
class PaymentMethod(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    card_type = db.Column(db.String(20))  # visa, mastercard, etc.
    last_four = db.Column(db.String(4))   # останні 4 цифри
    expiry_month = db.Column(db.Integer)
    expiry_year = db.Column(db.Integer)
    is_default = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)    

# --- Декоратори ---
def login_required(f):
    """Декоратор для перевірки авторизації адміністратора"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_logged_in' not in session:
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

# --- Утиліти ---
def get_date_range(period):
    """Повертає початкову та кінцеву дату для періоду (day, week, month, year)"""
    now = datetime.now()
    
    if period == 'day':
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
    elif period == 'week':
        # Початок тижня (понеділок)
        days_since_monday = now.weekday()
        start = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days_since_monday)
        end = start + timedelta(days=7)
    elif period == 'month':
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        if now.month == 12:
            end = start.replace(year=now.year + 1, month=1)
        else:
            end = start.replace(month=now.month + 1)
    elif period == 'year':
        start = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
        end = start.replace(year=now.year + 1)
    else:
        # ПЗа замовчуванням - сьогодні
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
    
    return start, end

def get_locale():
    """Налаштування визначення мови"""
    # 1. Якщо в сесії є обрана мова — використовуємо її
    if 'lang' in session:
        return session['lang']

    # 2. Інакше визначаємо мову за IP (якщо локально — UA за замовчуванням)
    # або за замовчуванням 'en'
    country_code = 'US'  # Дефолт, якщо GeoIP не працює
    if request.remote_addr == '127.0.0.1':
        country_code = 'UA'  # Для локальної розробки в Україні
    elif geoip_reader:
        try:
            match = geoip_reader.country(request.remote_addr)
            country_code = match.country.iso_code
        except Exception as e:
            print(f"Couldn't determine the country for the IP {request.remote_addr}: {e}")
            country_code = 'US'  # Дефолт, якщо IP не розпізнано

    if country_code == 'UA':
        return 'uk'
    else:
        return 'en'

def deg_to_direction(deg):
    """Перетворює градуси у напрямок вітру"""
    if deg is None: return ""
    directions = [_('N'), _('NE'), _('E'), _('SE'), _('S'), _('SW'), _('W'), _('NW')]
    ix = round(deg / 45) % 8
    return directions[ix]

def get_weather(lat, lon, lang, tz_str):
    """
    Отримує поточну погоду та прогноз на 5 днів.
    Повертає словник `weather_data_bundle` з ключами 'current' та 'forecast'.
    """
    # 1. URL для запитів
    current_weather_url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&units=metric&lang={lang}&appid={WEATHER_API_KEY}"
    forecast_url = f"https://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&units=metric&lang={lang}&appid={WEATHER_API_KEY}"
    
    weather_data_bundle = {'current': {}, 'forecast': []}

    # 2. Отримання ПОТОЧНОЇ погоди
    try:
        current_response = requests.get(current_weather_url)
        current_response.raise_for_status() 
        current_data = current_response.json()

        local_tz = pytz.timezone(tz_str)
        sunrise_utc = datetime.fromtimestamp(current_data['sys']['sunrise'], tz=pytz.utc)
        sunset_utc = datetime.fromtimestamp(current_data['sys']['sunset'], tz=pytz.utc)
   
        weather_data_bundle['current'] = {
            'temp': int(current_data['main']['temp']),
            'feels_like': int(current_data['main'].get('feels_like', current_data['main']['temp'])),
            'description': current_data['weather'][0]['description'].capitalize(),
            'icon': current_data['weather'][0]['icon'],
            'wind_speed': round(current_data['wind']['speed'], 1), 
            'wind_dir': deg_to_direction(current_data['wind'].get('deg')),
            'sunrise_time': sunrise_utc.astimezone(local_tz).strftime('%H:%M'),
            'sunset_time': sunset_utc.astimezone(local_tz).strftime('%H:%M')
        }
    except (requests.exceptions.RequestException, KeyError) as e:
        print(f"Error getting/parsing the current weather: {e}")
        weather_data_bundle['current'] = {
            'temp': 'N/A', 'feels_like': 'N/A', 'description': 'Weather data unavailable',
            'icon': '01d', 'wind_speed': 'N/A', 'wind_dir': '',
            'sunrise_time': 'N/A', 'sunset_time': 'N/A'
        }

    # 3. Отримання та обробка ПРОГНОЗУ на 5 днів
    try:
        forecast_response = requests.get(forecast_url)
        forecast_response.raise_for_status()
        forecast_data = forecast_response.json()

        daily_forecasts = {}  # Словник для групування даних за днями
        
        for item in forecast_data.get('list', []):
            date_key = datetime.fromtimestamp(item['dt']).strftime('%Y-%m-%d')
            
            if date_key not in daily_forecasts:
                daily_forecasts[date_key] = {
                    'date': format_date(datetime.strptime(date_key, '%Y-%m-%d'), 'd MMM'),
                    'min_temp': item['main']['temp_min'],
                    'max_temp': item['main']['temp_max'],
                    'descriptions': [item['weather'][0]['description']],
                    'icons': [item['weather'][0]['icon']]
                }
            else:
                daily_forecasts[date_key]['min_temp'] = min(daily_forecasts[date_key]['min_temp'], item['main']['temp_min'])
                daily_forecasts[date_key]['max_temp'] = max(daily_forecasts[date_key]['max_temp'], item['main']['temp_max'])
                daily_forecasts[date_key]['descriptions'].append(item['weather'][0]['description'])
                daily_forecasts[date_key]['icons'].append(item['weather'][0]['icon'])
        
        processed_forecast = []
        for date_str, data in daily_forecasts.items():
            final_description = max(set(data['descriptions']), key=data['descriptions'].count)
            final_icon = max(set(data['icons']), key=data['icons'].count)
            
            processed_forecast.append({
                'date': data['date'],
                'min_temp': int(data['min_temp']),
                'max_temp': int(data['max_temp']),
                'description': final_description.capitalize(),
                'icon': final_icon
            })
        weather_data_bundle['forecast'] = processed_forecast
    except (requests.exceptions.RequestException, KeyError) as e:
        print(f"Error receiving/parsing the weather forecast: {e}")
    
    return weather_data_bundle

def log_page_view(page_name):
    """Логування перегляду сторінки"""
    view = PageView(
        page_name=page_name,
        user_ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent', ''),
        session_id=session.get('session_id', '')
    )
    db.session.add(view)
    db.session.commit()

def log_calendar_generation(city, lat, lon, month, year, user_id=None):
    """Логування генерації календаря"""
    calendar = CalendarGeneration(
        user_id=user_id,
        city=city,
        latitude=lat,
        longitude=lon,
        month=month,
        year=year,
        user_ip=request.remote_addr
    )
    db.session.add(calendar)
    db.session.commit()

# Утиліти для адмінки
def get_crop_emoji(crop):
    """Повертає емодзі для культури"""
    crop_emojis = {
        'tomatoes': '🍅',
        'carrots': '🥕', 
        'herbs': '🌿',
        'potatoes': '🥔',
        'strawberries': '🍓',
        'fruit-trees': '🌳',
        'flowers': '🌸',
        'indoor-plants': '🪴',
        'greenhouse': '🏠',
        'lettuce': '🥬',
        'pumpkins': '🎃',
        'onions': '🧅',
        'cucumbers': '🥒',
        'peppers': '🌶️',
        'corn': '🌽',
        'beans': '🫘',
        'radishes': '🥗',
        'cabbage': '🥬',
        
        # Премиум-функции
        'weather-alerts': '🌦️',
        'pest-control': '🐛',
        'harvest-timing': '⏰',
        'expert-support': '👨‍🌾',
        
        # Дефолт
        'more': '+'
    }
    return crop_emojis.get(crop, '🌱')

def get_crop_name(crop):
    """Повертає перекладену назву культури"""
    # Використовуємо систему перекладів Flask-Babel
    crop_names = {
        # Культуры
        'tomatoes': _('Tomatoes'),
        'carrots': _('Carrots'),
        'herbs': _('Herbs'),
        'potatoes': _('Potatoes'),
        'strawberries': _('Strawberries'),
        'fruit-trees': _('Fruit Trees'),
        'flowers': _('Flowers'),
        'indoor-plants': _('Indoor Plants'),
        'greenhouse': _('Greenhouse Crops'),
        'lettuce': _('Lettuce'),
        'pumpkins': _('Pumpkins'),
        'onions': _('Onions'),
        'cucumbers': _('Cucumbers'),
        'peppers': _('Peppers'),
        'corn': _('Corn'),
        'beans': _('Beans'),
        'radishes': _('Radishes'),
        'cabbage': _('Cabbage'),
        
        # Премиум-функции
        'weather-alerts': _('Weather Alerts'),
        'pest-control': _('Pest Control'),
        'harvest-timing': _('Harvest Timing'),
        'expert-support': _('Expert Support'),
        
        # Дефолт
        'more': _('Other')
    }
    return crop_names.get(crop, _(crop.replace('-', ' ').title()))

# Реєструємо функцію селектора локалі
babel.init_app(app, locale_selector=get_locale)

# Додаємо функції в контекст шаблонів
@app.context_processor
def utility_processor():
    return dict(
        get_crop_emoji=get_crop_emoji,
        get_crop_name=get_crop_name,
        current_datetime=datetime.now(),   # Для роботи з датами в шаблонах
        timedelta=timedelta  # Додаємо timedelta для обчислень дат в шаблонах
    )

# --- Фільтри Jinja2 для шаблонів ---
@app.template_filter('moon_phase_icon')
def moon_phase_icon(phase_name):
    icons = {'New Moon': '🌑', 'First Quarter': '🌓', 'Full Moon': '🌕', 'Last Quarter': '🌗', 
             'Waxing Crescent': '🌒', 'Waning Crescent': '🌘', 'Waxing Gibbous': '🌔', 'Waning Gibbous': '🌖'}
    return icons.get(phase_name, '')

@app.template_filter('zodiac_icon')
def zodiac_icon(sign_name):
    icons = {'Aries': '♈︎', 'Taurus': '♉︎', 'Gemini': '♊︎', 'Cancer': '♋︎', 'Leo': '♌︎', 'Virgo': '♍︎', 
             'Libra': '♎︎', 'Scorpio': '♏︎', 'Sagittarius': '♐︎', 'Capricornus': '♑︎', 'Aquarius': '♒︎', 
             'Pisces': '♓︎', 'Ophiuchus': '⛎'}
    return icons.get(sign_name, '')

# --- ОСНОВНІ МАРШРУТИ (ФРОНТЕНД) ---

@app.route('/')
def index():
    """Головна сторінка (форма вибору дати та міста)"""
    log_page_view('index')
    
    # Місяці для форми
    months = [
        {'value': 1, 'name': _('January')}, {'value': 2, 'name': _('February')},
        {'value': 3, 'name': _('March')}, {'value': 4, 'name': _('April')},
        {'value': 5, 'name': _('May')}, {'value': 6, 'name': _('June')},
        {'value': 7, 'name': _('July')}, {'value': 8, 'name': _('August')},
        {'value': 9, 'name': _('September')}, {'value': 10, 'name': _('October')},
        {'value': 11, 'name': _('November')}, {'value': 12, 'name': _('December')}
    ]
    current_year = datetime.now().year
    years = list(range(current_year - 1, current_year + 3))  # от 2024 до 2027

    return render_template('index.html',
                           current_lang=get_locale(),
                           months=months,
                           years=years,
                           current_month_value=datetime.now().month,
                           current_year_value=current_year)
                           
@app.route('/generator')
def generator():
    """Сторінка генератора календаря (спрощена версія)"""
    log_page_view('generator')
    
    # Місяці для форми
    months = [
        {'value': 1, 'name': _('January')}, {'value': 2, 'name': _('February')},
        {'value': 3, 'name': _('March')}, {'value': 4, 'name': _('April')},
        {'value': 5, 'name': _('May')}, {'value': 6, 'name': _('June')},
        {'value': 7, 'name': _('July')}, {'value': 8, 'name': _('August')},
        {'value': 9, 'name': _('September')}, {'value': 10, 'name': _('October')},
        {'value': 11, 'name': _('November')}, {'value': 12, 'name': _('December')}
    ]
    current_year = datetime.now().year
    years = list(range(current_year - 1, current_year + 3))

    return render_template('generator.html',
                           current_lang=get_locale(),
                           months=months,
                           years=years,
                           current_month_value=datetime.now().month,
                           current_year_value=current_year)                           

@app.route('/about')
def about():
    """Рендерить сторінку 'Про календар'."""
    log_page_view('about')
    return render_template('about.html', current_lang=get_locale())

@app.route('/subscription')
def subscription():
    """Рендерить сторінку з тарифами (перейменована з pricing)."""
    log_page_view('subscription')
    return render_template('subscription.html', current_lang=get_locale())

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Реєстрація користувача для безкоштовного акаунту."""
    print(f"🎯 register() called with method: {request.method}")
    
    if request.method == 'POST':
        print(f"📝 Processing POST registration request")
        
        # Отримуємо дані форми
        full_name = request.form.get('fullName')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        confirm_password = request.form.get('confirmPassword')
        
        print(f"👤 Name: {full_name}")
        print(f"📧 Email: {email}")
        print(f"📱 Phone: {phone}")
        print(f"🔒 Password received: {len(password) if password else 0} characters")
        
        # Отримуємо дані міста
        city_name = request.form.get('city')
        city_data_json = request.form.get('city_data')
        
        print(f"🏙️ City (name): {city_name}")
        print(f"📍 City data (JSON): {city_data_json}")
        
        notification = request.form.get('notification')
        theme = request.form.get('theme')
        crops = request.form.get('crops')
        
        print(f"🔔 Notifications: {notification}")
        print(f"🎨 Theme: {theme}")
        print(f"🌱 Crops: {crops}")
        
        # Проста валідація
        if password != confirm_password:
            print(f"❌ Passwords do not match")
            flash('Passwords do not match!', 'error')
            return redirect(url_for('register'))

        # Перевіряємо, чи не зайнятий email
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            print(f"❌ Email {email} already registered")
            flash('This email is already registered.', 'error')
            return redirect(url_for('register'))

        # Хешуємо пароль
        hashed_password = generate_password_hash(password)
        print(f"🔐 Password hashed")

        # Обробляємо дані міста
        city_to_save = city_name
        city_lat = None
        city_lon = None 
        city_tz = None
        
        if city_data_json:
            try:
                city_data = json.loads(city_data_json)
                city_to_save = city_data.get('name', city_name)
                city_lat = city_data.get('lat')
                city_lon = city_data.get('lon')
                city_tz = city_data.get('tz')
                print(f"✅ Coordinates extracted: {city_to_save} ({city_lat}, {city_lon}) [{city_tz}]")
            except json.JSONDecodeError as e:
                print(f"❌ Error parsing city JSON: {e}")
        else:
            print(f"⚠️ City coordinates data not received")
        
        # Створюємо нового користувача
        try:
            new_user = User(
                full_name=full_name,
                email=email,
                password_hash=hashed_password,
                phone=phone,
                city=city_to_save,
                city_latitude=city_lat,
                city_longitude=city_lon,
                city_timezone=city_tz,
                notification_method=notification,
                theme_preference=theme,
                interested_crops=crops,
                is_subscribed=False
            )
            
            print(f"👤 User object created")
            
            db.session.add(new_user)
            db.session.commit()
            
            print(f"💾 User saved to DB with ID: {new_user.id}")
            
            # Створюємо запис про підписку
            session['user_id'] = new_user.id
            session['user_name'] = new_user.full_name
            
            print(f"🔐 Session set: user_id={new_user.id}")
            
            flash('Account created successfully! Welcome to BioDyne!', 'success')
            print(f"🎉 Flash message added")
            print(f"🔄 Redirecting to dashboard...")
            
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            print(f"❌ ERROR saving user: {e}")
            db.session.rollback()
            flash('Error creating account', 'error')
            return redirect(url_for('register'))
        
    # GET запит - показуємо форму
    print(f"📄 Showing registration form")
    log_page_view('register')
    return render_template('profile.html', current_lang=get_locale())

@app.route('/premium-register', methods=['GET', 'POST'])
def premium_register():
    """Реєстрація преміум аккаунта."""
    if request.method == 'POST':
        print(f"🎯 premium_register() called with method: {request.method}")
        
        # Отримуємо дані з форми
        full_name = request.form.get('fullName')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        confirm_password = request.form.get('confirmPassword')
        
        print(f"👤 Name: {full_name}")
        print(f"📧 Email: {email}")
        print(f"📱 Phone: {phone}")
        print(f"🔒 Password received: {len(password) if password else 0} characters")
        
        # Отримуємо дані про місто
        city_name = request.form.get('city')
        city_data_json = request.form.get('city_data')
        
        print(f"🏙️ City (name): {city_name}")
        print(f"📍 City data (JSON): {city_data_json}")
        
        # Отримуємо вибрані культури і функції
        crops = request.form.get('crops')  # Вибрані культури
        features = request.form.getlist('features')  # Преміум функції (чекбокси)
        all_features = request.form.get('all_features')  # Об'єднані дані з JS
        
        print(f"🌱 Crops: {crops}")
        print(f"⭐ Features: {features}")
        print(f"🔗 All features: {all_features}")
        
        # Об'єднуємо всі інтереси користувача
        user_interests = []
        if crops:
            user_interests.extend([crop.strip() for crop in crops.split(',') if crop.strip()])
        if features:
            user_interests.extend(features)
        if all_features:
            user_interests.extend([item.strip() for item in all_features.split(',') if item.strip()])
        
        # Прибираємо дублікати і створюємо підсумкову рядок
        final_interests = ','.join(list(set(user_interests)))
        
        print(f"🎯 Final interests: {final_interests}")
        
        # Платіжні дані
        card_number = request.form.get('cardNumber')
        expiry = request.form.get('expiry')
        cvv = request.form.get('cvv')
        billing_address = request.form.get('billingAddress')
        
        print(f"💳 Card: {card_number}")
        
        # Проста валідація
        if password != confirm_password:
            print(f"❌ Passwords do not match")
            flash('Passwords do not match!', 'error')
            return redirect(url_for('premium_register'))

        # Перевіряємо, чи не зайнятий email
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            print(f"❌ Email {email} already registered")
            flash('This email has already been registered.', 'error')
            return redirect(url_for('premium_register'))

        # Хешуємо пароль
        hashed_password = generate_password_hash(password)
        print(f"🔐 Password hashed")

        # Обробка даних про місто
        city_to_save = city_name
        city_lat = None
        city_lon = None 
        city_tz = None
        
        if city_data_json:
            try:
                city_data = json.loads(city_data_json)
                city_to_save = city_data.get('name', city_name)
                city_lat = city_data.get('lat')
                city_lon = city_data.get('lon')
                city_tz = city_data.get('tz')
                print(f"✅ Coordinates extracted: {city_to_save} ({city_lat}, {city_lon}) [{city_tz}]")
            except json.JSONDecodeError as e:
                print(f"❌ Error parsing city JSON: {e}")
        else:
            print(f"⚠️ City coordinates data not received")
        
        # Створюємо нового користувача
        try:
            new_user = User(
                full_name=full_name,
                email=email,
                phone=phone,
                password_hash=hashed_password,
                city=city_to_save,
                city_latitude=city_lat,
                city_longitude=city_lon,
                city_timezone=city_tz,
                notification_method='both',  # Преміум користувачі отримують всі повідомлення
                theme_preference='auto',
                interested_crops=final_interests,  # Зберігаємо всі інтереси: культури + преміум функції
                is_subscribed=True,  # Преміум план
                subscription_date=datetime.utcnow()
            )
            
            print(f"👤 User object created")
            
            db.session.add(new_user)
            db.session.flush()  # Щоб отримати ID користувача
            
            print(f"💾 User saved to DB with ID: {new_user.id}")
            
            # Создаем запись о подписке
            subscription = Subscription(
                user_id=new_user.id,
                plan_type='premium',
                status='active',
                start_date=datetime.utcnow(),
                end_date=datetime.utcnow() + timedelta(days=30),  # Перший місяць
                payment_amount=9.99,
                payment_method='credit_card'
            )
            
            db.session.add(subscription)
            
            # Створюємо запис про платіжний метод (якщо дані передані)
            if card_number and expiry and cvv:
                # Визначаємо тип карти по першій цифрі
                card_type = 'visa'
                if card_number.startswith('4'):
                    card_type = 'visa'
                elif card_number.startswith('5'):
                    card_type = 'mastercard'
                elif card_number.startswith('3'):
                    card_type = 'amex'
                
                # Отримуємо останні 4 цифри
                last_four = card_number.replace(' ', '')[-4:]
                
                # Парсім дату закінчення
                expiry_parts = expiry.split('/')
                if len(expiry_parts) == 2:
                    expiry_month = int(expiry_parts[0])
                    expiry_year = int('20' + expiry_parts[1])  # Додаємо 20 до року
                    
                    payment_method = PaymentMethod(
                        user_id=new_user.id,
                        card_type=card_type,
                        last_four=last_four,
                        expiry_month=expiry_month,
                        expiry_year=expiry_year,
                        is_default=True
                    )
                    
                    db.session.add(payment_method)
                    print(f"💳 Payment method saved: {card_type} ending in {last_four}")
            
            db.session.commit()
            
            print(f"💳 Subscription and payment method created")
            
            # Автоматично логінім користувача
            session['user_id'] = new_user.id
            session['user_name'] = new_user.full_name
            session['user_plan'] = 'premium'
            
            print(f"🔐 Session set: user_id={new_user.id}")
            
            flash('Premium subscription is activated! Welcome to BioDyne Premium!', 'success')
            print(f"🎉 Flash message added")
            print(f"🔄 Redirecting to dashboard...")
            
            return redirect(url_for('dashboard'))
            
        except Exception as e:
            print(f"❌ ERROR saving user: {e}")
            db.session.rollback()
            flash('Error creating premium account', 'error')
            return redirect(url_for('premium_register'))
        
    # GET request - show form
    print(f"📄 Showing premium registration form")
    log_page_view('premium_register')
    
    # Вираховуємо дату закінчення пробної версії для відображення
    trial_end_date = (datetime.now() + timedelta(days=7)).strftime('%B %d, %Y')
    
    return render_template('premium_register.html', 
                         current_lang=get_locale(),
                         trial_end_date=trial_end_date)

@app.route('/profile-login')
def profile_login():
    """Сторінка входу в профіль."""
    # Якщо користувач уже авторизований, перенаправляємо в дашборд
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    
    log_page_view('profile_login')
    return render_template('profile_login.html', current_lang=get_locale())

@app.route('/signin', methods=['POST'])
def signin():
    """Обробка входу користувача."""
    email = request.form.get('email')
    password = request.form.get('password')
    remember = request.form.get('remember')
    
    if not email or not password:
        flash('Enter your email and password', 'error')
        return redirect(url_for('profile_login'))
    
    user = User.query.filter_by(email=email).first()
    
    if user and check_password_hash(user.password_hash, password):
        session['user_id'] = user.id
        session['user_name'] = user.full_name
        session['user_plan'] = 'premium' if user.is_subscribed else 'free'
        
        # Оновлюємо час останньої активності
        user.last_activity = datetime.utcnow()
        db.session.commit()
        
        flash('Welcome!', 'success')
        return redirect(url_for('dashboard'))
    else:
        flash('Invalid email or password', 'error')
        return redirect(url_for('profile_login'))

def find_city_data(city_name, lang='en'):
    """
    Знаходить дані міста в cities_multi_lang.json за назвою
    Повертає координати та часовий пояс
    """
    try:
        json_path = os.path.join(app.static_folder, 'cities', 'cities_multi_lang.json')
        
        with open(json_path, 'r', encoding='utf-8') as f:
            cities_data = json.load(f)
        
        # Шукаємо місто за назвою в поточній локалізації
        for city in cities_data:
            city_names = city.get('name', {})
            
            # Перевіряємо назву на поточній мові
            if lang in city_names and city_names[lang].lower() == city_name.lower():
                return {
                    'lat': city.get('lat'),
                    'lon': city.get('lon'),
                    'tz': city.get('tz', 'UTC'),
                    'country': city.get('country', '')
                }
            
            # Якщо не знайдено на поточній мові, перевіряємо всі варіанти
            for lang_code, name in city_names.items():
                if name.lower() == city_name.lower():
                    return {
                        'lat': city.get('lat'),
                        'lon': city.get('lon'),
                        'tz': city.get('tz', 'UTC'),
                        'country': city.get('country', '')
                    }
        
        return None
        
    except Exception as e:
        print(f"Error reading the cities file: {e}")
        return None

# Додати цю функцію ПЕРЕД функцією dashboard() в app.py

def get_current_moon_phase_emoji():
    """
    Отримує поточну фазу місяця у вигляді емодзі, використовуючи astro_service.py
    """
    try:
        # Імпортуємо функції з astro_service
        from astro_service import get_moon_phase
        import swisseph as swe
        
        # Поточний час в UTC
        now_utc = datetime.utcnow()
        jd_ut = swe.utc_to_jd(
            now_utc.year, now_utc.month, now_utc.day,
            now_utc.hour, now_utc.minute, now_utc.second
        )[0]
        
        # Отримуємо назву фази місяця
        moon_phase_name = get_moon_phase(jd_ut)
        
        # Маппінг назв фаз на емодзі
        phase_mapping = {
            # Англійські варіанти
            'New Moon': '🌑',
            'Waxing Crescent': '🌒', 
            'First Quarter': '🌓',
            'Waxing Gibbous': '🌔',
            'Full Moon': '🌕',
            'Waning Gibbous': '🌖',
            'Last Quarter': '🌗',
            'Waning Crescent': '🌘',
            # Українські варіанти 
            'Новий місяць':'🌑',
            'Зростаючий півмісяць':'🌒',
            'Перша чверть':'🌓', 
            'Зростаючий місяць':'🌔',
            'Повний місяць':'🌕',
            'Спадаючий місяць':'🌖',
            'Остання чверть':'🌗',
            'Спадаючий півмісяць':'🌘'
        }
        
        return phase_mapping.get(moon_phase_name, '🌑')
        
    except Exception as e:
        print(f"Error calculating the moon phase: {e}")
        return '🌑'

@app.route('/dashboard')
def dashboard():
    """Дашборд користувача з реальними даними."""
    print(f"🎯 dashboard() called")
    print(f"🔍 Current session: {dict(session)}")
    
    # Перевіряємо авторизацію
    if 'user_id' not in session:
        print(f"❌ user_id not in session, redirecting to login")
        return redirect(url_for('profile_login'))
    
    user_id = session['user_id']
    print(f"👤 user_id from session: {user_id}")
    
    user = User.query.get(user_id)
    if not user:
        print(f"❌ User with ID {user_id} not found in DB")
        session.clear()
        return redirect(url_for('profile_login'))
    
    print(f"✅ User found: {user.full_name} ({user.email})")
    print(f"🏙️ City: {user.city}")
    print(f"📍 Coordinates: {user.city_latitude}, {user.city_longitude}")
    
    log_page_view('dashboard')
    
    # Отримуємо кількість активних культур користувача
    active_crops = 0
    if user.interested_crops:
        try:
            if isinstance(user.interested_crops, str):
                active_crops = len([crop.strip() for crop in user.interested_crops.split(',') if crop.strip()])
            else:
                active_crops = len(user.interested_crops)
        except:
            active_crops = 0
    
    # Отримуємо генерації календарів користувача за цей місяць
    month_ago = datetime.utcnow() - timedelta(days=30)
    calendars_this_month = CalendarGeneration.query.filter(
        CalendarGeneration.user_id == user.id,
        CalendarGeneration.timestamp >= month_ago
    ).count()
    
    # Отримуємо погоду та фазу місяця
    weather_data = {'temp': 'N/A', 'description': 'City not specified'}
    moon_phase = '🌑'
    
    if user.city:
        print(f"🌤️ Getting weather for city: {user.city}")
        # Спочатку намагаємося використати збережені координати
        if user.city_latitude and user.city_longitude and user.city_timezone:
            lat = user.city_latitude
            lon = user.city_longitude  
            timezone_str = user.city_timezone
            print(f"✅ Using saved coordinates: {lat}, {lon}, {timezone_str}")
        else:
            # Якщо немає координат, шукаємо в JSON файлі
            city_data = find_city_data(user.city, get_locale())
            if city_data:
                lat = city_data['lat']
                lon = city_data['lon'] 
                timezone_str = city_data['tz']
                print(f"✅ Coordinates found in JSON: {lat}, {lon}, {timezone_str}")
                
                # Оновлюємо користувача знайденими координатами
                user.city_latitude = lat
                user.city_longitude = lon
                user.city_timezone = timezone_str
                db.session.commit()
            else:
                print(f"❌ City '{user.city}' not found")
                weather_data = {'temp': 'N/A', 'description': f'City "{user.city}" not found'}
                lat = lon = timezone_str = None
        
        # Отримуємо погоду, якщо доступні координати
        if lat and lon and timezone_str:
            try:
                lang = get_locale()
                weather_bundle = get_weather(lat, lon, lang, timezone_str)
                if weather_bundle and 'current' in weather_bundle:
                    weather_data = {
                        'temp': f"{weather_bundle['current']['temp']}°C",
                        'description': weather_bundle['current']['description'],
                        'icon': weather_bundle['current']['icon'],
                        'forecast': weather_bundle.get('forecast', [])
                    }
                    print(f"✅ Weather loaded: {weather_data['temp']}, {weather_data['description']}")
                
                # Отримуємо фазу місяця
                moon_phase = get_current_moon_phase_emoji()
                        
            except Exception as e:
                print(f"❌ Error getting weather data: {e}")
                weather_data = {'temp': 'N/A', 'description': f'Error getting data for {user.city}'}
        else:
            weather_data = {'temp': 'N/A', 'description': f'City "{user.city}" not found in database'}
    
    # Отримуємо сьогоднішні завдання
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    today_end = today_start + timedelta(days=1)
    tasks_today = CalendarGeneration.query.filter(
        CalendarGeneration.user_id == user.id,
        CalendarGeneration.timestamp >= today_start,
        CalendarGeneration.timestamp < today_end
    ).count()
    
    # Додаємо базові завдання для всіх користувачів
    if user.is_subscribed:
        tasks_today += 2  # Преміум користувачі отримують більше рекомендацій
    else:
        tasks_today += 1  # Базові рекомендації
    
    # Отримуємо статистику активності користувача
    total_calendars = CalendarGeneration.query.filter_by(user_id=user.id).count()
    
    # Отримуємо останні згенеровані календарі
    recent_calendars = CalendarGeneration.query.filter_by(user_id=user.id).order_by(
        CalendarGeneration.timestamp.desc()
    ).limit(5).all()
    
    dashboard_data = {
        'user': user,
        'active_crops': active_crops,
        'tasks_today': tasks_today,
        'weather_temp': weather_data.get('temp', 'N/A'),
        'weather_description': weather_data.get('description', 'Data unavailable'),
        'weather_icon': weather_data.get('icon', '01d'),
        'weather_forecast': weather_data.get('forecast', []),
        'moon_phase': moon_phase,
        'total_calendars': total_calendars,
        'calendars_this_month': calendars_this_month,
        'recent_calendars': recent_calendars
    }
    
    print(f"📊 Dashboard data prepared, rendering template...")
    
    return render_template('user_dashboard.html',
                         current_lang=get_locale(),
                         **dashboard_data)
    
@app.route('/signout')
def signout():
    """Вихід з акаунту."""
    session.clear()
    flash('You are logged out', 'info')
    return redirect(url_for('profile_login'))

@app.route('/profile-settings')
def profile_settings():
    """Налаштування профілю."""
    # Перевіряємо авторизацію
    if 'user_id' not in session:
        return redirect(url_for('profile_login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        session.clear()
        return redirect(url_for('profile_login'))
    
    # Отримуємо підписки користувача
    user_subscriptions = Subscription.query.filter_by(user_id=user.id).order_by(
        Subscription.created_at.desc()
    ).all()
    
    # Отримуємо платіжний метод
    user_payment_method = PaymentMethod.query.filter_by(
        user_id=user.id, 
        is_default=True
    ).first()
    
    log_page_view('profile_settings')
    return render_template('profile_settings.html', 
                         current_lang=get_locale(),
                         user=user,
                         user_subscriptions=user_subscriptions,
                         user_payment_method=user_payment_method)

@app.route('/pricing')
def pricing_redirect():
    """Перенаправлення зі старого URL на новий."""
    return redirect(url_for('subscription'), code=301)

@app.route('/set_language')
def set_language():
    """Обробка вибору мови"""
    lang = request.args.get('lang')
    if lang in ['en', 'uk']:
        session['lang'] = lang
        
    # Визначаємо, звідки прийшов користувач
    referrer = request.referrer
    
    # Якщо користувач був на сторінці календаря
    if referrer and 'calendar' in referrer and 'last_calendar_params' in session:
        params = session['last_calendar_params']
        return redirect(url_for('calendar', **params))
    
    # Якщо користувач був на будь-якій іншій сторінці, повертаємо його туди
    if referrer:
        # Витягуємо назву сторінки з referrer
        if referrer.endswith('/about'):
            return redirect(url_for('about'))
        elif referrer.endswith('/subscription'):
            return redirect(url_for('subscription'))
        elif referrer.endswith('/profile-login'):
            return redirect(url_for('profile_login'))
    
    # За замовчуванням повертаємо на головну сторінку
    return redirect(url_for('index'))

@app.route('/calendar', methods=['GET', 'POST']) 
def calendar():
    """Перехід на календар після відправки форми"""
    data = {}
    # Якщо це перша відправка форми
    if request.method == 'POST':
        try:
            data = {
                'city': request.form.get('city'),
                'latitude': float(request.form.get('latitude')),
                'longitude': float(request.form.get('longitude')),
                'timezone': request.form.get('timezone'),
                'year': int(request.form.get('year')),
                'month': int(request.form.get('month'))
            }
            session['last_calendar_params'] = data
        except (TypeError, ValueError) as e:
            print(f"Error when parsing form parameters POST: {e}")
            return redirect(url_for('index'))
    # Якщо це GET-запит (наприклад, після зміни мови)
    else:
        try:
            # Намагаємося взяти параметри з URL
            data = {
                'city': request.args.get('city'),
                'latitude': float(request.args.get('latitude')),
                'longitude': float(request.args.get('longitude')),
                'timezone': request.args.get('timezone'),
                'year': int(request.args.get('year')),
                'month': int(request.args.get('month'))
            }
            session['last_calendar_params'] = data  # Оновлюємо сесію
        except (TypeError, ValueError):
            # Якщо в URL немає даних, намагаємося взяти з сесії
            data = session.get('last_calendar_params')
            if not data:
                return redirect(url_for('index'))

    # Витягуємо дані для використання
    city = data.get('city')
    lat = data.get('latitude')
    lon = data.get('longitude')
    timezone_str = data.get('timezone')  # <-- Змінна з правильною TZ
    year = data.get('year')
    month = data.get('month')

    # Перевірка, що всі дані на місці
    if not all([city, lat, lon, timezone_str, year, month]):
        return redirect(url_for('index'))

    tz = pytz.timezone(timezone_str)
    today_local = datetime.now(tz).date()

    display_date = dt.date(year, month, 1)
    formatted_date_header = format_date(display_date, format='MMMM yyyy')

    weather = get_weather(lat, lon, get_locale(), timezone_str)
    calendar_data = get_month_calendar(year, month, lat, lon, timezone_str, today_local) if get_month_calendar else []
    
    # Логуємо генерацію календаря
    log_calendar_generation(city, lat, lon, month, year)
    log_page_view('calendar')
    
    return render_template('calendar.html',
                           current_lang=get_locale(),
                           city=city,
                           formatted_date_header=formatted_date_header,
                           calendar_data=calendar_data,
                           weather=weather)

# --- АДМІНІСТРАТИВНІ МАРШРУТИ (БЕКЕНД) ---

@app.route('/admin')
def admin_login():
    """Сторінка входу для адміністратора"""
    if 'admin_logged_in' in session:
        return redirect(url_for('admin_dashboard'))
    return render_template('admin/login.html')

@app.route('/admin/login', methods=['POST'])
def admin_do_login():
    """Обробка входу адміністратора"""
    username = request.form.get('username')
    password = request.form.get('password')
    
    if not username or not password:
        flash('Введіть логін і пароль', 'error')
        return redirect(url_for('admin_login'))
    
    admin = Admin.query.filter_by(username=username).first()
    
    if admin and check_password_hash(admin.password_hash, password):
        session['admin_logged_in'] = True
        session['admin_id'] = admin.id
        session['admin_username'] = admin.username
        
        # Оновлюємо час останнього входу
        admin.last_login = datetime.utcnow()
        db.session.commit()
        
        flash('Успішний вхід в систему', 'success')
        return redirect(url_for('admin_dashboard'))
    else:
        flash('Невірний логін або пароль', 'error')
        return redirect(url_for('admin_login'))

@app.route('/admin/logout')
@login_required
def admin_logout():
    """Вихід з системи"""
    session.clear()
    flash('Ви вийшли з системи', 'info')
    return redirect(url_for('admin_login'))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    """Головна сторінка адмін-панелі з реальними даними"""
    
    # Отримуємо основну статистику
    total_users = User.query.count()
    subscribed_users = User.query.filter_by(is_subscribed=True).count()
    
    # Статистика за сьогодні
    today_start, today_end = get_date_range('day')
    today_registrations = User.query.filter(
        User.registration_date >= today_start,
        User.registration_date < today_end
    ).count()
    
    today_calendars = CalendarGeneration.query.filter(
        CalendarGeneration.timestamp >= today_start,
        CalendarGeneration.timestamp < today_end
    ).count()
    
    today_views = PageView.query.filter(
        PageView.timestamp >= today_start,
        PageView.timestamp < today_end
    ).count()
    
    # Статистика за тиждень
    week_start = today_start - timedelta(days=7)
    new_registrations = User.query.filter(
        User.registration_date >= week_start
    ).count()
    
    new_subscriptions = Subscription.query.filter(
        Subscription.created_at >= today_start,
        Subscription.created_at < today_end
    ).count()
    
    # Останні користувачі
    recent_users = User.query.order_by(User.registration_date.desc()).limit(5).all()
    
    # Останні підписки
    recent_subscriptions = db.session.query(Subscription, User).join(User).order_by(
        Subscription.created_at.desc()
    ).limit(5).all()
    
    # Підписки, що закінчуються (протягом 7 днів)
    expire_date = datetime.utcnow() + timedelta(days=7)
    expiring_subscriptions = Subscription.query.filter(
        Subscription.end_date <= expire_date,
        Subscription.status == 'active'
    ).all()
    
    return render_template('admin/dashboard.html', 
                         total_users=total_users,
                         subscribed_users=subscribed_users,
                         today_registrations=today_registrations,
                         today_calendars=today_calendars,
                         today_views=today_views,
                         new_registrations=new_registrations,
                         new_subscriptions=new_subscriptions,
                         recent_users=recent_users,
                         recent_subscriptions=recent_subscriptions,
                         expiring_subscriptions=expiring_subscriptions)

@app.route('/admin/users')
@login_required
def admin_users_list():
    """Список всіх користувачів з фільтрацією"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    filter_type = request.args.get('filter', 'all')
    
    query = User.query
    
    # Застосовуємо пошук
    if search:
        query = query.filter(
            db.or_(
                User.full_name.contains(search),
                User.email.contains(search),
                User.city.contains(search)
            )
        )
    
    # Застосовуємо фільтри
    if filter_type == 'subscribers':
        query = query.filter_by(is_subscribed=True)
    elif filter_type == 'free':
        query = query.filter_by(is_subscribed=False)
    elif filter_type == 'recent':
        week_ago = datetime.utcnow() - timedelta(days=7)
        query = query.filter(User.registration_date >= week_ago)
    
    users = query.order_by(User.registration_date.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/users.html',
                         users=users, 
                         search=search)

@app.route('/admin/user/<int:user_id>', methods=['GET', 'POST', 'DELETE'])
@login_required
def admin_user_detail(user_id):
    """Детальна інформація про користувача"""
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        # Оновлення даних користувача
        data = request.get_json()
        
        user.full_name = data.get('full_name', user.full_name)
        user.email = data.get('email', user.email)
        user.phone = data.get('phone', user.phone)
        user.city = data.get('city', user.city)
        user.notification_method = data.get('notification_method', user.notification_method)
        user.theme_preference = data.get('theme_preference', user.theme_preference)
        
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Дані користувача оновлені'})
    
    elif request.method == 'DELETE':
        # Видалення користувача
        # Видалення пов'язаних записів
        CalendarGeneration.query.filter_by(user_id=user_id).delete()
        Subscription.query.filter_by(user_id=user_id).delete()
        PaymentMethod.query.filter_by(user_id=user_id).delete()
        
        # Видаляємо користувача
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Користувача видалено'})
    
    # GET запит - показуємо сторінку
    # Отримуємо історію генерації календарів
    calendars = CalendarGeneration.query.filter_by(user_id=user_id).order_by(
        CalendarGeneration.timestamp.desc()
    ).limit(10).all()
    
    # Отримуємо підписки
    subscriptions = Subscription.query.filter_by(user_id=user_id).order_by(
        Subscription.created_at.desc()
    ).all()
    
    # Парсимо культури, що цікавлять
    interested_crops = []
    if user.interested_crops:
        try:
            if isinstance(user.interested_crops, str):
                # Якщо це рядок, розділяємо по комах
                interested_crops = [crop.strip() for crop in user.interested_crops.split(',') if crop.strip()]
            else:
                # Якщо це вже список
                interested_crops = user.interested_crops
        except:
            interested_crops = []
    
    return render_template('admin/user_detail.html',
                         user=user,
                         calendars=calendars,
                         subscriptions=subscriptions,
                         interested_crops=interested_crops)

@app.route('/admin/user/<int:user_id>/send-notification', methods=['POST'])
@login_required
def admin_send_notification(user_id):
    """Відправка сповіщення користувачу"""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    message = data.get('message')
    
    if not message:
        return jsonify({'success': False, 'message': 'Повідомлення не може бути порожнім'})
    
    # Тут має бути логіка відправки сповіщення (відправка email або push-сповіщення)
    # Поки повертаємо успіх
    return jsonify({'success': True, 'message': 'Повідомлення надіслано'})

@app.route('/admin/user/<int:user_id>/reset-password', methods=['POST'])
@login_required
def admin_reset_password(user_id):
    """Скидання пароля користувача"""
    user = User.query.get_or_404(user_id)
    
    # Генеруємо новий пароль
    new_password = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(12))
    
    # Хешуємо та зберігаємо
    user.password_hash = generate_password_hash(new_password)
    db.session.commit()
    
    # Тут має бути логіка відправки нового пароля на email
    # Поки повертаємо успіх
    
    return jsonify({'success': True, 'message': f'Новий пароль: {new_password}'})

@app.route('/admin/subscribers')
@login_required
def admin_subscribers_list():
    """Список підписників"""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    status_filter = request.args.get('status', '')
    plan_filter = request.args.get('plan', '')
    
    query = db.session.query(Subscription, User).join(User)
    
    # Фільтр за пошуком
    if search:
        query = query.filter(
            db.or_(
                User.full_name.contains(search),
                User.email.contains(search)
            )
        )
    
    # Фільтр за статусом
    if status_filter and status_filter != 'all':
        query = query.filter(Subscription.status == status_filter)
    
    # Фільтр за планом
    if plan_filter and plan_filter != 'all':
        query = query.filter(Subscription.plan_type == plan_filter)
    
    subscribers = query.order_by(Subscription.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/subscribers.html', 
                         subscribers=subscribers, 
                         search=search,
                         status_filter=status_filter)
                                           
@app.route('/admin/statistics')
@login_required
def admin_statistics():
    """Сторінка статистики з реальними даними"""
    period = request.args.get('period', 'month')
    
    start_date, end_date = get_date_range(period)
    
    # Основна статистика
    page_views = PageView.query.filter(
        PageView.timestamp >= start_date,
        PageView.timestamp < end_date
    ).count()
    
    calendars_generated = CalendarGeneration.query.filter(
        CalendarGeneration.timestamp >= start_date,
        CalendarGeneration.timestamp < end_date
    ).count()
    
    new_registrations = User.query.filter(
        User.registration_date >= start_date,
        User.registration_date < end_date
    ).count()
    
    new_subscriptions = Subscription.query.filter(
        Subscription.created_at >= start_date,
        Subscription.created_at < end_date
    ).count()
    
    # Доходи
    total_revenue = db.session.query(db.func.sum(Subscription.payment_amount)).filter(
        Subscription.created_at >= start_date,
        Subscription.created_at < end_date
    ).scalar() or 0
    
    # Топ міст за календарями
    top_cities = db.session.query(
        CalendarGeneration.city,
        db.func.count(CalendarGeneration.id).label('count')
    ).filter(
        CalendarGeneration.timestamp >= start_date,
        CalendarGeneration.timestamp < end_date,
        CalendarGeneration.city.isnot(None)
    ).group_by(CalendarGeneration.city).order_by(
        db.func.count(CalendarGeneration.id).desc()
    ).limit(10).all()
    
    # Розподіл за планами підписки
    subscription_plans = db.session.query(
        Subscription.plan_type,
        db.func.count(Subscription.id).label('count')
    ).filter(
        Subscription.created_at >= start_date,
        Subscription.created_at < end_date
    ).group_by(Subscription.plan_type).all()
    
    # Популярні сторінки
    top_pages = db.session.query(
        PageView.page_name,
        db.func.count(PageView.id).label('count')
    ).filter(
        PageView.timestamp >= start_date,
        PageView.timestamp < end_date
    ).group_by(PageView.page_name).order_by(
        db.func.count(PageView.id).desc()
    ).limit(10).all()
    
    # Активність користувачів
    active_users = db.session.query(db.func.count(db.distinct(User.id))).filter(
        User.last_activity >= start_date,
        User.last_activity < end_date
    ).scalar() or 0
    
    return render_template('admin/statistics.html',
                         period=period,
                         page_views=page_views,
                         calendars_generated=calendars_generated,
                         new_registrations=new_registrations,
                         new_subscriptions=new_subscriptions,
                         total_revenue=round(total_revenue, 2),
                         top_cities=top_cities,
                         subscription_plans=subscription_plans,
                         top_pages=top_pages,
                         active_users=active_users,
                         start_date=start_date,
                         end_date=end_date)

# API роути для AJAX запитів
@app.route('/api/statistics_data')
@login_required
def api_statistics_data():
    """API для отримання даних статистики з графіками"""
    period = request.args.get('period', 'month')
    
    # Отримуємо часовий діапазон
    start_date, end_date = get_date_range(period)
    
    # Основна статистика
    stats = {
        'views': PageView.query.filter(
            PageView.timestamp >= start_date,
            PageView.timestamp < end_date
        ).count(),
        'calendars': CalendarGeneration.query.filter(
            CalendarGeneration.timestamp >= start_date,
            CalendarGeneration.timestamp < end_date
        ).count(),
        'registrations': User.query.filter(
            User.registration_date >= start_date,
            User.registration_date < end_date
        ).count(),
        'subscriptions': Subscription.query.filter(
            Subscription.created_at >= start_date,
            Subscription.created_at < end_date
        ).count()
    }
    
    # Дані для графіка реєстрацій
    chart_labels = []
    chart_data = []
    
    if period == 'day':
        # Погодинна статистика за день
        for hour in range(24):
            hour_start = start_date + timedelta(hours=hour)
            hour_end = hour_start + timedelta(hours=1)
            
            registrations = User.query.filter(
                User.registration_date >= hour_start,
                User.registration_date < hour_end
            ).count()
            
            chart_labels.append(f"{hour:02d}:00")
            chart_data.append(registrations)
    
    elif period == 'week':
        # Щоденна статистика за тиждень
        for day in range(7):
            day_start = start_date + timedelta(days=day)
            day_end = day_start + timedelta(days=1)
            
            registrations = User.query.filter(
                User.registration_date >= day_start,
                User.registration_date < day_end
            ).count()
            
            chart_labels.append(day_start.strftime('%d.%m'))
            chart_data.append(registrations)
    
    elif period == 'month':
        # Щоденна статистика за місяць (останні 30 днів)
        for day in range(30):
            day_start = start_date + timedelta(days=day)
            day_end = day_start + timedelta(days=1)
            
            registrations = User.query.filter(
                User.registration_date >= day_start,
                User.registration_date < day_end
            ).count()
            
            chart_labels.append(day_start.strftime('%d.%m'))
            chart_data.append(registrations)
    
    elif period == 'year':
        # Помісячна статистика за рік
        current_date = start_date
        while current_date < end_date:
            if current_date.month == 12:
                next_month = current_date.replace(year=current_date.year + 1, month=1)
            else:
                next_month = current_date.replace(month=current_date.month + 1)
            
            registrations = User.query.filter(
                User.registration_date >= current_date,
                User.registration_date < next_month
            ).count()
            
            chart_labels.append(current_date.strftime('%m.%Y'))
            chart_data.append(registrations)
            current_date = next_month
    
    # Додаткова статистика
    stats['active_users'] = db.session.query(db.func.count(db.distinct(User.id))).filter(
        User.last_activity >= start_date,
        User.last_activity < end_date
    ).scalar() or 0
    
    stats['total_revenue'] = db.session.query(db.func.sum(Subscription.payment_amount)).filter(
        Subscription.created_at >= start_date,
        Subscription.created_at < end_date
    ).scalar() or 0
    
    # Топ міста
    top_cities = db.session.query(
        CalendarGeneration.city,
        db.func.count(CalendarGeneration.id).label('count')
    ).filter(
        CalendarGeneration.timestamp >= start_date,
        CalendarGeneration.timestamp < end_date,
        CalendarGeneration.city.isnot(None)
    ).group_by(CalendarGeneration.city).order_by(
        db.func.count(CalendarGeneration.id).desc()
    ).limit(10).all()
    
    # Топ сторінки
    top_pages = db.session.query(
        PageView.page_name,
        db.func.count(PageView.id).label('count')
    ).filter(
        PageView.timestamp >= start_date,
        PageView.timestamp < end_date
    ).group_by(PageView.page_name).order_by(
        db.func.count(PageView.id).desc()
    ).limit(10).all()
    
    # Підписки за планами
    subscription_plans = db.session.query(
        Subscription.plan_type,
        db.func.count(Subscription.id).label('count')
    ).filter(
        Subscription.created_at >= start_date,
        Subscription.created_at < end_date
    ).group_by(Subscription.plan_type).all()
    
    return jsonify({
        'stats': stats,
        'chart': {
            'labels': chart_labels,
            'data': chart_data
        },
        'top_cities': [(city, count) for city, count in top_cities],
        'top_pages': [(page, count) for page, count in top_pages],
        'subscription_plans': [(plan, count) for plan, count in subscription_plans]
    })

@app.route('/api/admin/user/<int:user_id>/toggle-subscription', methods=['POST'])
@login_required
def toggle_user_subscription(user_id):
    """API для перемикання статусу підписки користувача"""
    user = User.query.get_or_404(user_id)
    
    # Перемикаємо статус підписки
    user.is_subscribed = not user.is_subscribed
    
    if user.is_subscribed:
        # Якщо активуємо підписку, встановлюємо дату
        if not user.subscription_date:
            user.subscription_date = datetime.utcnow()
        
        # Створюємо запис про підписку, якщо її немає
        existing_subscription = Subscription.query.filter_by(
            user_id=user_id, 
            status='active'
        ).first()
        
        if not existing_subscription:
            new_subscription = Subscription(
                user_id=user_id,
                plan_type='premium',
                status='active',
                start_date=datetime.utcnow(),
                end_date=datetime.utcnow() + timedelta(days=30),
                payment_amount=9.99,
                payment_method='admin_activation'
            )
            db.session.add(new_subscription)
    else:
        # Якщо деактивуємо, оновлюємо статус підписок
        Subscription.query.filter_by(
            user_id=user_id, 
            status='active'
        ).update({'status': 'cancelled'})
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'is_subscribed': user.is_subscribed,
        'message': f'Подписка {"активована" if user.is_subscribed else "деактивована"}'
    })

@app.route('/api/admin/subscription/<int:subscription_id>/cancel', methods=['POST'])
@login_required
def cancel_subscription(subscription_id):
    """Скасування підписки"""
    subscription = Subscription.query.get_or_404(subscription_id)
    subscription.status = 'cancelled'
    
    # Оновлюємо статус користувача
    user = User.query.get(subscription.user_id)
    if user:
        user.is_subscribed = False
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Підписка скасована'
    })

@app.route('/api/admin/subscription/<int:subscription_id>/renew', methods=['POST'])
@login_required 
def renew_subscription(subscription_id):
    """Відновлення підписки"""
    subscription = Subscription.query.get_or_404(subscription_id)
    subscription.status = 'active'
    subscription.end_date = datetime.utcnow() + timedelta(days=30)
    
    # Оновлюємо статус користувача
    user = User.query.get(subscription.user_id)
    if user:
        user.is_subscribed = True
        user.subscription_date = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Підписка відновлена'
    })

# --- Обробники помилок ---
@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

# --- Функція ініціалізації бази даних ---
def init_admin_db():
    """Ініціалізація адмінської частини бази даних"""
    print("Initializing admin database...")
    with app.app_context():
        # Створюємо адміністратора за замовчуванням
        admin_user = Admin.query.filter_by(username='admin').first()
        if not admin_user:
            hashed_password = generate_password_hash('admin123')  
            new_admin = Admin(username='admin', password_hash=hashed_password)
            db.session.add(new_admin)
            db.session.commit()
            print("Default admin user created: admin/admin123")
            print("⚠️  Важливо: змініть пароль адміністратора після першого входу!")
        
        
        print("Database initialized. Users will be created through registration.")
        
    print("Admin database initialization complete.")    
            
def init_db():
    """Оновлена функція ініціалізації"""
    print("Initializing database...")
    with app.app_context():
        db.create_all()
        print("Database tables created/checked.")
    
    # Ініціалізуємо адмінські дані
    init_admin_db()
    
    print("Database initialization complete.")
    
# --- Запуск Flash-програми ---
if __name__ == '__main__':
    init_db()
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)    