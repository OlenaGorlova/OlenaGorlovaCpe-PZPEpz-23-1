#!/usr/bin/env python3
"""
Скрипт запуска объединенного Flask приложения BioDyne
"""

import os
import sys

# Добавляем текущую директорию в путь Python
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from app import app, init_db
    
    if __name__ == '__main__':
        print("🌱 Запуск BioDyne - объединенного приложения")
        print("=" * 50)
        
        # Инициализируем базу данных
        with app.app_context():
            init_db()
            print("✅ База данных инициализирована")
        
        print("🌐 Фронтенд доступен по адресу: http://localhost:5000")
        print("🔧 Админ-панель доступна по адресу: http://localhost:5000/admin")
        print("📧 Данные для входа в админку: admin / admin123")
        print("=" * 50)
        
        # Запускаем приложение
        port = int(os.environ.get('PORT', 5000))
        app.run(host='0.0.0.0', port=port, debug=True)
        
except ImportError as e:
    print(f"❌ Ошибка импорта: {e}")
    print("💡 Убедитесь, что все зависимости установлены: pip install -r requirements.txt")
    sys.exit(1)
except Exception as e:
    print(f"❌ Ошибка запуска: {e}")
    sys.exit(1)